//: Playground - noun: a place where people can play

import UIKit


var i = 1...100
for w in i {
    switch (i) {
    case _ where w % 5 == 0:
        print( (w), "Bingo!!!")
    case _ where w % 2 == 0:
        print((w), "par")
    case 30...40:
        print((w), "Viva Swift")
    default:
        print((w), "impar")
}
}
